# Decision-Tree
A decision tree is a powerful tool in data science that is used for both classification and regression tasks. It is a flowchart-like tree structure where each internal node denotes a test on an attribute, each branch represents an outcome of the test, and each leaf node holds a class label. 
